package com.example.microproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail;
    private Spinner spinnerDepartment, spinnerSemester, spinnerEvent;
    private Button buttonRegister;
    private DatabaseHelper RegisterDbHelper;
    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        spinnerDepartment = findViewById(R.id.spinnerDepartment);
        spinnerSemester = findViewById(R.id.spinnerSemester);
        spinnerEvent = findViewById(R.id.spinnerEvent);
        buttonRegister = findViewById(R.id.buttonRegister);

        // Initialize database
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();
// Retrieve the string arrays from resources


        // Populate Department spinner
        ArrayAdapter<CharSequence> departmentAdapter = ArrayAdapter.createFromResource(
                this, R.array.departments_array, android.R.layout.simple_spinner_item);
        departmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDepartment.setAdapter(departmentAdapter);

        // Populate Semester spinner
        ArrayAdapter<CharSequence> semesterAdapter = ArrayAdapter.createFromResource(
                this, R.array.semesters_array, android.R.layout.simple_spinner_item);
        semesterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSemester.setAdapter(semesterAdapter);

        // Populate Event spinner
        ArrayAdapter<CharSequence> eventAdapter = ArrayAdapter.createFromResource(
                this, R.array.events_array, android.R.layout.simple_spinner_item);
        eventAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEvent.setAdapter(eventAdapter);

        // Set click listener for Register button
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                // Get user input
                String name = editTextName.getText().toString();
                String email = editTextEmail.getText().toString();
                String department = spinnerDepartment.getSelectedItem().toString();
                String semester = spinnerSemester.getSelectedItem().toString();
                String event = spinnerEvent.getSelectedItem().toString();

                if (validateForm())
                {
                    // TODO: Code for submitting the form goes here
                    Toast.makeText(MainActivity.this, "Form submitted successfully", Toast.LENGTH_SHORT).show();
                } else
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }

                // Insert data into database
                ContentValues values = new ContentValues();
                values.put(DatabaseHelper.COLUMN_NAME, name);
                values.put(DatabaseHelper.COLUMN_EMAIL, email);
                values.put(DatabaseHelper.COLUMN_DEPARTMENT, department);
                values.put(DatabaseHelper.COLUMN_SEMESTER, semester);
                values.put(DatabaseHelper.COLUMN_EVENT, event);
                db.insert(DatabaseHelper.TABLE_NAME, null, values);



                // Clear input fields
                editTextName.setText("");
                editTextEmail.setText("");
                spinnerDepartment.setSelection(0);
                spinnerSemester.setSelection(0);
                spinnerEvent.setSelection(0);

                // Display success message
                //Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateForm()
    {
        if (editTextName.getText().toString().isEmpty()) {
            editTextName.setError("Please enter your name");
            editTextName.requestFocus();
            return false;
        }
        if (editTextEmail.getText().toString().isEmpty()) {
            editTextEmail.setError("Please enter your email");
            editTextEmail.requestFocus();
            return false;
        }
        if (spinnerDepartment.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select your department", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (spinnerSemester.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select your semester", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (spinnerEvent.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select your event", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    @Override
    protected void onDestroy() {
        db.close();
        super.onDestroy();
    }
}